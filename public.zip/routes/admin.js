var express = require('express');
var admin = express.Router();


/* GET users listing. */
// admin.get('/admin', function(req, res) {
//   res.render('/admin/admin');
// });

// admin.get('/admin/typography', function(req, res) {
//   res.render('admin/typography');
// });

module.exports = admin;
