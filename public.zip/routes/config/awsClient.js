
// const AWS=require('aws-sdk');
// const region= 'Asia Pacific (Mumbai) ap-south-1'
// const accessKeyId='AKIA6M6ZG37XLZBVRIXL'
// const secretKey= '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';
// AWS.config.update({region, credentials : {accessKeyId:accessKeyId,secretAccessKey:secretKey}});
// module.exports={
//     AWS
// }
